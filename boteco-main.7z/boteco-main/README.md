<img src="https://user-images.githubusercontent.com/61523977/177602277-0cb2a53d-e415-4462-9244-e241e9f8ac3c.png" width="20%" heigth="20%">
<h2 align"center">Projeto Boteco</h1><img src="https://img.shields.io/github/stars/Amaral1973/multiplataforma?style=social"/>
<h4 align="center">🚧 Em construção... 🚧</h4>
<h4>💻 Sobre o projeto</h4>
<hr/>
Projeto de um boteco, baseado em C#, usando classe, e stored procedures. Usando o framework Windows Forms, projeto de desktop, com o banco de dados SQL.
